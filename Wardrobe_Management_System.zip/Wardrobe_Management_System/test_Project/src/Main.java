public class Main {
    public static void main(String Args[]){
        UI_Home homepage = new UI_Home();
        //CRUDE.display();
    }
}
//    //This class serves to link both the login and mail classes. Login class is not required for the assessment, but can be added.
//
//    //Everything below this comment is a part of https://github.com/renboy1222/webAppCrudJDBC-intelliJ/blob/main/webAppCrudJDBC/UserDAO.java
//    // The tutorial is at https://www.youtube.com/watch?v=wsPLIAG7c7c
//    //Consider making a separate project to check how it functions
//    //Change your current code to follow the same logic, and get the program working.
//}